ReactDOM.render(
    <div>
        <h1>REACTJS</h1>
    </div>,
    document.getElementById('root')
);