/**
 * Created by BUOfPeThui on 12/11/2017.
 */
function sayHello() {
    document.write('Say Hello !!!');
}

module.exports = sayHello;