/**
 * Created by BUOfPeThui on 12/11/2017.
 */
// document.write('Hello I am ReactJS SSR');
// var hello = require('./components/hello');
//
// hello();

var React = require('react');
var ReactDom = require('react-dom');

ReactDom.render(
    <a href="http://khoapham.vn">Khoa Pham Online</a>,
    document.getElementById('root')
);